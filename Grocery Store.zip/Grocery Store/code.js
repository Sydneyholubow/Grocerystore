//This starts the game at its home screen
setScreen("welcomeScreen");
//These values represent how much of each item amd the overall cost (score) of the total items
var score = 0;
var fries = 0;
var milk = 0;
var cake = 0;
var burger = 0;
var bread = 0;
// When the start button is clicked, the screen will show the wall of grocieries
// The cart total label will display the score with a $ in front of it
onEvent("startBtn", "click", function( ) {
  setScreen("groceryWallScreen");
  setText("cartTotal", "$" +score);
  //This hides the money images on the finish Screen
  hideElement("2DmoneySign");
  hideElement("3DmoneySign");
  hideElement("moneyBag");
});
// When you click the return button on the finish page, it will bring you to the home page
onEvent("returnBtn", "click", function( ) {
  setScreen("welcomeScreen");
});
// all variables reset to 0 so that the user can play again without saving its previous plays
// when on the checkout page, all labels are reset to blank and will change when an item is clicked
onEvent("startBtn", "click", function( ) {
  score = 0;
  setText("cartTotal", "$" + score);
  fries = 0;
  setText("friesTotal", "");
  milk = 0;
  setText("milkTotal", "");
  cake = 0;
  setText("cakeTotal", "");
  burger = 0;
  setText("burgerTotal", "");
  bread = 0;
  setText("breadTotal", "");
});
// When the finish button is clicked on checkout screen, it takes you to the finish screen
// there, the user will rate the game/their shopping experience
onEvent("finishBtn", "click", function( ) {
  setScreen("finishScreen");
  // This shows a random dollar sign image on the final page
  var randomMoney = randomNumber(1,3);
  if (randomMoney == 1) {
    showElement("2DmoneySign");
  } else {
    if (randomMoney == 2) {
      showElement("3DmoneySign");
    } else {
      showElement("moneyBag");
    }
  }
  //This takes the final total of your cart total and the game says if that is expensive or not
  //If total is 100 or above, it would have a different message than if it was below
  if (score >= 100) {
   setText("finishLabel", ("Your cart total is $" +score)+ ". That is a lot of money!");
  } else {
    setText("finishLabel", ("Your cart total is $" +score)+ ". That isn't too expensive");
  }
});
// When the checkout button is clicked, a new screen with a reciept will appear
// The reciept will be displaying the cost(score) of the items bought. This will displayed in the total label
onEvent("checkoutBtn", "click", function( ) {
  playSound("assets/category_bell/vibrant_cash_register_open_positive_game_open.mp3", false);
  setScreen("checkoutScreen");
  setText("total", "$" + score);
});
//When you click on the fries, the total(score) will go up by 2
//The total amount of fries will go up by 1 every time it is clicked. 
//This will appear on the checkout screen and it will appear as Fries x total amount of fries
onEvent("fries", "click", function( ) {
  upCost(2);
  fries = fries + 1;
  setText("friesTotal", "Fries x " + fries);
});
//When you click on the milk, the total(score) will go up by 4
//The total amount of milk will go up by 1 every time it is clicked. 
//This will appear on the checkout screen and it will appear as Milk x total amount of milk
onEvent("milk", "click", function( ) {
  upCost(4);
  milk = milk + 1;
  setText("milkTotal", "Milk x " + milk);
});
//When you click on the cake, the total(score) will go up by 11
//The total amount of cake will go up by 1 every time it is clicked. 
//This will appear on the checkout screen and it will appear as Cake x total amount of cake
onEvent("cake", "click", function( ) {
  upCost(11);
  cake = cake + 1;
  setText("cakeTotal", "Cake x " + cake);
});
//When you click on the bread, the total(score) will go up by 3
//The total amount of bread will go up by 1 every time it is clicked. 
//This will appear on the checkout screen and it will appear as Bread x total amount of bread
onEvent("bread", "click", function( ) {
  upCost(3);
  bread = bread + 1;
  setText("breadTotal", "Bread x " + bread);
});
//When you click on the burger, the total(score) will go up by 6
//The total amount of burgers will go up by 1 every time it is clicked. 
//This will appear on the checkout screen and it will appear as Burgers x total amount of burgers
onEvent("burger", "click", function( ) {
  upCost(6);
  burger = burger + 1;
  setText("burgerTotal", "Burgers x " + burger);
});
//this function is a form of abstraction. It allows each item to cost its own individual amount, and add that to the cart total
function upCost(cost) {
  score = score + cost;
  setText("cartTotal", "$" +score);
}
